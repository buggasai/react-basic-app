import Home from './home/page'
export default Home