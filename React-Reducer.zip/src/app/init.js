export const init = {
    name : "",
    loc : ""
}