import React from 'react'

export function Header() {
  return (
    <div className='container-fluid w-100 bg-primary text-center'>
       Header
    </div>
  )
}
