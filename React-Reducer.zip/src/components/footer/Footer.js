import React from 'react'

export function Footer() {
  return (
    <div className='bg-danger text-center'>Footer</div>
  )
}
